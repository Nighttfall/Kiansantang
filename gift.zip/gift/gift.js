$(document).ready(function() {
  $(".click").click(function() {
    // Menampilkan tombol NEXT
    setTimeout(function() {
    $(".NEXT").css("display", "inline");
  }, 1000);
});
});